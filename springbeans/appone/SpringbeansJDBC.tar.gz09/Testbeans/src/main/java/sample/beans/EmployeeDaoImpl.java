package sample.beans;

import org.springframework.jdbc.core.JdbcTemplate;


public class EmployeeDaoImpl implements IEmployeeDao {

    private JdbcTemplate jt;

    public void setjt(JdbcTemplate  jdbcTemplate)
    {
        this.jt = jdbcTemplate;
    }
    public int saveEmp(int empId, String empName, Double empSal) {

        String sql = "insert into Employee values(?,?,?)";
        int c = jt.update(sql,empId,empName,empSal);
        return c;
    }
}
