package sample.beans;


public interface IEmployeeDao {

    int saveEmp(int empId,String empName, Double empSal);
}
