package sample.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Object pobj = context.getBean("empDao");
        IEmployeeDao e = (IEmployeeDao) pobj;
       int c = e.saveEmp(14,"prasannakumar",22510.00);
        System.out.println(c);
    }
}
